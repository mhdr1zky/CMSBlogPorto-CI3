<style>
	.footer {
  position: fixed;
  width: 100%;
  bottom: 0;
}
</style>			
			<section class="text-center col">
				<hr>
			<div class="container text-center">
				
<footer class="blog-footer text-center col">
  <p>Blog template built <a href="https://">&copy; Bootstrap <?php echo date('Y');?></a> by <a href="https://">@mhdr1zky</a>.</p>
  <p>
    <a href="#">Back to top</a>
  </p>
</footer>
</div></section>